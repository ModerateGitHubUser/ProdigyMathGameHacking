[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["util.d"](_util_d_.md)

# Module: "util.d"

## Index

### Type aliases

* [TODO](_util_d_.md#todo)

## Type aliases

###  TODO

Ƭ **TODO**: *any*
