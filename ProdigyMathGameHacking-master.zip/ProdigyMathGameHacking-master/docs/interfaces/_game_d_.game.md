[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["game.d"](../modules/_game_d_.md) › [Game](_game_d_.game.md)

# Interface: Game

## Hierarchy

* **Game**

## Index

### Properties

* [id](_game_d_.game.md#id)
* [prodigy](_game_d_.game.md#prodigy)

## Properties

###  id

• **id**: *number*

___

###  prodigy

• **prodigy**: *[Prodigy](_prodigy_d_.prodigy.md)*
