[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["prodigy.d"](../modules/_prodigy_d_.md) › [Prodigy](_prodigy_d_.prodigy.md)

# Interface: Prodigy

## Hierarchy

* **Prodigy**

## Index

### Properties

* [game](_prodigy_d_.prodigy.md#game)
* [player](_prodigy_d_.prodigy.md#player)
* [version](_prodigy_d_.prodigy.md#version)

## Properties

###  game

• **game**: *[Game](_game_d_.game.md)*

___

###  player

• **player**: *[Player](../classes/_player_d_.player.md)*

___

###  version

• **version**: *string*
