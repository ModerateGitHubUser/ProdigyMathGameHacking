[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["pixi.d"](../modules/_pixi_d_.md) › [PIXI](_pixi_d_.pixi.md)

# Interface: PIXI

## Hierarchy

* **PIXI**

## Index

### Properties

* [game](_pixi_d_.pixi.md#game)

## Properties

###  game

• **game**: *[Game](_game_d_.game.md)*
