## A substitute console to evaluate hacks if your console is blocked!
