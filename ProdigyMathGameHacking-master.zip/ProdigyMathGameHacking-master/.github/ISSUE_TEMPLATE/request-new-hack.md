---
name: Request New Hack
about: Request a new hack!
title: "[HR]"
labels: ''
assignees: ''

---

**Describe the hack in 5 words or less:**
<!-- Example: Membership Hack-->

**Have you made sure this hack isn't available yet?* (Yes/No)**
