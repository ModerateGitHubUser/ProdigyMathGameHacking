---
name: Bug report
about: Describe an issue
title: "[BUG]"
labels: Bug
assignees: ''

---

***Description***:


***Replication***:


***Images***:


***Additional Errors***:
