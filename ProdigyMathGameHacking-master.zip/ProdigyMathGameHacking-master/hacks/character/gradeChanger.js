//> Grade set hack
//>> Changes your grade to 1-8 whatever you put 
_.player.grade = 1
