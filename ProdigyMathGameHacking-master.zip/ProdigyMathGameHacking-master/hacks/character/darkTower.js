//> Dark Tower hack
//>> Makes your Dark Tower floor to 100, you can add any number, just delete 100 and replace it with the number of you choice if you want!
_.player.data.tower = 100;
