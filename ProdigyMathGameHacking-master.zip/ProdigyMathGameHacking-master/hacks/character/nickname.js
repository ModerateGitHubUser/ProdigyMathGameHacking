//> Nickname script
//>> Sets your nickname.
_.player.name.data.nickname = 7; 

/* Put a number one through 55.  The associations are as follows:
 * 1.  Buccaneer
 * 2.  Captain
 * 3.  First-Mate
 * 4.  Beard the Pirate
 * 5.  Treasure Hunter
 * 6.  Robo
 * 7.  The W12  - 4R D
 * 8.  Dancemaster
 * 9.  Bot 30 00 
 * 10. The Machinist
 * 11. The Digger
 * 12. Surveyor
 * 13. Excavator
 * 14. Archaeologist
 * 15. Saurus
 * 16. Pilot
 * 17. The Skyfolk
 * 18. Cloudeater
 * 19. Stormchaser
 * 20. , Puyoy!
 * 21. Firelord
 * 22. Flame Wielder
 * 23. Pyromancer
 * 24. Coalwalker
 * 25. The Hottie
 * 26. Of the Forest
 * 27. Botanist
 * 28. The Green
 * 29. Forest Walker
 * 30. Wild
 * 31. Ice Carver
 * 32. Frozen
 * 33. The Snowman
 * 34. Mountaineer Climber
 * 35. The Cool
 * 36. The Firedancer
 * 37. Woodland
 * 38. The Wild
 * 39. Snapdragon
 * 40. The Firefly
 * 41. Chef
 * 42. Hotshot
 * 43. Firebreather
 * 44. Flame Dancer
 * 45. Bolt-Head
 * 46. The Mechanic
 * 47. Super
 * 48. Chill
 * 49. Mountaineer
 * 50. Frostbringer
 * 51. Aquatic
 * 52. Fishy
 * 53. Of the Sea
 * 54. Mer
 * 55. Glub-Glub
 * null. Original Name
 */
