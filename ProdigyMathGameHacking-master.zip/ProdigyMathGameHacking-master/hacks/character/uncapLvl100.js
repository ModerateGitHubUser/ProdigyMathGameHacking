//> Uncap level hack
//>> Customizes your level to any number you put in. This hack doesn't save.
_.player.getLevel = () => _.player.data.level = numberhere
