//> Set level hack
//>> Sets your level to 100.
_.player.data.level = 100
