//> Bounty score hack
//>> Sets your bounty score to 100.
_.player.data.bountyScore = 100;
