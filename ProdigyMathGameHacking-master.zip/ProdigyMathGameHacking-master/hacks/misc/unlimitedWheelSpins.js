//> Unlimited wheel spins hack
//>> Gives player unlimited spins on the Wheel of Wonder. (Also Twilight Wheel?)
_.constants.constants["GameConstants.Debug.UNLIMITED_WHEEL_SPINS"] = true;
