//> No monster respawn hack
//>> Disables monster spawning.
_.constants.constants["GameConstants.Features.ENABLE_MONSTER_SPAWNING"] = false;
