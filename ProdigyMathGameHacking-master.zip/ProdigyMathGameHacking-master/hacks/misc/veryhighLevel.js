//> Level 1e69
//>> Doesn't save if you logout.
_.instance.prodigy.player.getLevel = () => _.instance.prodigy.player.data.level = 1e69;
