//> Disable inactivy prompt
//>> No inactivity prompts.
_.constants.constants["GameConstants.Inactivity.LOG_OUT_TIMER_SECONDS"] = 0;
