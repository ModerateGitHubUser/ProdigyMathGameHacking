//> Tutorial skipper
//>> Skips Prodigy's tutorial
_.functions.completeTutorial();
