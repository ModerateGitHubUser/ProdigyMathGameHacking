//> Infinite HP hack
//>> This hack gives you infinite HP
_.player.modifiers.maxHearts = Infinity;
