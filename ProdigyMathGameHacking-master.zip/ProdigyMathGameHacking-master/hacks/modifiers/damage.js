//> Infinite damage hack
//>> This hack allows you to deal infinite damage

_.player.modifiers.damage = Infinity;
