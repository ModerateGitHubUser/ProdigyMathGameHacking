# Hack Instructions

These are the JavaScript-code based hacks. <b>Note that a graphical cheat menu is included with the [Official Extension](https://github.com/Prodigy-Hacking/ProdigyMathGameHacking/wiki/How-to-install-hacks). You do <i>not</i> have to use these.</b>

If you are encountering errors, tell us at our [Discord server](https://discord.gg/XQDfbfq) and go to the #support channel.
