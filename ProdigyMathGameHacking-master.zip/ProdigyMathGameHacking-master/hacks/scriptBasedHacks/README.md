# Script based hacks are back!

## If you had issues with our [Official Extension](https://github.com/Prodigy-Hacking/ProdigyMathGameHacking/wiki/How-to-install-hacks) is a good alternative! It is much more limited then the redirect hack, but it doesn't require Chrome extensions, and if you can make bookmarklets, even the Chrome console.

# ***PLEASE NOTE***
### You need to bypass the console with a bookmarklet, with the below script: 
```js
javascript:console.log=console.clear=console.dir=_=>{}
```
### You need to:
### 1. Make a new bookmark
### 2. Set the URL to the code above.
#### It should look like this:
![bkmrk-img](https://media.discordapp.net/attachments/685965137361895476/748600604619833434/unknown.png)

### So click it when you log in to Prodigy, otherwise, you won't be able to open console!

----

### Made by AVN1114

#### Note: These hacks require you to reload after usage.

----
### Possible issues:
### - JWT token sometimes isn't defined in `localStorage` after a while, so if you are experiencing issues, reload the page and perform your desired hacks quickly!
