//> Invincibility hack
//>> Makes the opponent miss every time
_.instance.prodigy.battle.constructor.MOD_DEFAULTS.invincible = true;
