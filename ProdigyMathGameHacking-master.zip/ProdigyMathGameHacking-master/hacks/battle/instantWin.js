//> Instant win hack
//>> Instantly beats any monster
_.instance.prodigy.game.state.states.Battle.startVictory();
