//> Unlimited catch attempts
//>> Gives you unlimited tries to catch a monster and keep it as your pet
_.player.catchAttempt = 99999;
