// Change the number 1 to whatever item you need.
// Equipment

// Hat
_.player.equipment.hat = 1;
// Outfit
_.player.equipment.outfit = 1;
// Weapon
_.player.equipment.weapon = 1
// Spell Relic
_.player.equipment.spellRelic = 1;
//Boots
_.player.equipment.boots = 1;
// Cloud mount (Only 1)
_.player.equipment.mount = 1
// Follow
_.player.equipment.follow = 1;



// Appearance

// Gender (only "Male"/"Female")
_.player.appearance = "male"
// Hair style
_.player.appearance.hairStyle = 1;
// Hair color
_.player.appearance.hairColor = 1;
// Eye color
_.player.appearance.eyeColor = 1;
// Skin color
_.player.appearance.skinColor = 1;
// Face
_.player.appearance.face = 1;
