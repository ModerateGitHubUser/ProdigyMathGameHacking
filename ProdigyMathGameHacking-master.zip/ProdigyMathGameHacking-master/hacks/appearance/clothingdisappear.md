This isn't so much of a hack. It's just something silly.
1. Open inspect element and go to the network tab
2. Right click any jpg (for this case anything that has outfits)
3. Click block.
4. A thing should pop up at the bottom of the screen called request blocking.
5. Click the + icon.
6. A text box should appear. Type in outfit and click add.
7. Reload the page.
8. Your done! Now outfits won't appear! To get rid of this, just uncheck outfits under the request blocking tab then reload.
NOTE: This will work on basically anything on you. To do hats, replace outfit with hat. If you want to do pets, replace outfit with pet ect, ect.
